
<!DOCTYPE html><html lang="en-US"><head>
			<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="http://gmpg.org/xfn/11">
		
<title>Mobile Payment SHOP &#8211; Easy Payment Easy Life</title>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Mobile Payment SHOP &raquo; Feed" href="http://localhost/Mopay_Dashboard/feed/" />
<link rel="alternate" type="application/rss+xml" title="Mobile Payment SHOP &raquo; Comments Feed" href="http://localhost/Mopay_Dashboard/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="Mobile Payment SHOP &raquo; Products Feed" href="http://localhost/Mopay_Dashboard/shop/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/localhost\/Mopay_Dashboard\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.9"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=3.5.2' type='text/css' media='all' />
<style id='woocommerce-layout-inline-css' type='text/css'>

	.infinite-scroll .woocommerce-pagination {
		display: none;
	}
</style>
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=3.5.2' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=3.5.2' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/vendors/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='best-commerce-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A300%2C400%2C500%2C700%7CMontserrat%3A300%2C400%2C500%2C600%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-sidr-css'  href='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/vendors/sidr/css/jquery.sidr.dark.min.css?ver=2.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-slick-css'  href='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/vendors/slick/slick.min.css?ver=1.5.9' type='text/css' media='all' />
<link rel='stylesheet' id='best-commerce-style-css'  href='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/style.css?ver=1.0.6' type='text/css' media='all' />
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<link rel='https://api.w.org/' href='http://localhost/Mopay_Dashboard/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost/Mopay_Dashboard/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://localhost/Mopay_Dashboard/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.9" />
<meta name="generator" content="WooCommerce 3.5.2" />
<meta name="referrer" content="always"/>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<link rel="icon" href="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay3-1-32x32.png" sizes="32x32" />
<link rel="icon" href="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay3-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay3-1-180x180.png" />
<meta name="msapplication-TileImage" content="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay3-1-270x270.png" />
</head>

<body class="home archive post-type-archive post-type-archive-product wp-custom-logo woocommerce woocommerce-page woocommerce-no-js site-layout-boxed global-layout-right-sidebar">

	<div id="page" class="hfeed site"><a class="skip-link screen-reader-text" href="#content">Skip to content</a>		<div class="mobile-nav-wrap">
			<a id="mobile-trigger" href="#mob-menu"><i class="fa fa-list-ul" aria-hidden="true"></i></a>
										<a id="mobile-trigger2" href="#category-list"><i class="fa fa-folder-o" aria-hidden="true"></i></a>
						<div id="mob-menu">
				<ul id="menu-top-menu" class="menu"><li class=" current-menu-item"><a href="http://localhost/Mopay_Dashboard/"><i class="fa fa-home" aria-hidden="true"></i>Home</a></li><li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="http://localhost/Mopay_Dashboard/about/">About</a></li>
<li id="menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="http://localhost/Mopay_Dashboard/blog/">Blog</a></li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22"><a href="http://localhost/Mopay_Dashboard/contact/">Contact</a></li>
<li id="menu-item-28" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-28"><a href="http://localhost/Mopay/index.php/auth">Login</a></li>
</ul>			</div><!-- #mob-menu -->

		</div><!-- .mobile-nav-wrap -->
		
			<div id="tophead">
			<div class="container">

				
						<div class="my-login">
			<ul>
									<li>
						<a href="http://localhost/Mopay_Dashboard/my-account/"><i class="fa fa-user" aria-hidden="true"></i>Login/Register</a>
					</li>
							</ul>
		</div><!-- .my-login -->
		
									<div id="header-social">
						<div class="widget best_commerce_widget_social"><ul id="menu-social-links-menu" class="menu"><li id="menu-item-23" class="fa fa-download menu-item menu-item-type-custom menu-item-object-custom menu-item-23"><a title="Download APK" target="_blank" href="https://drive.google.com/file/d/1EGAOLDNHpJ8J7pTfwxiETPf59jO3f-mO/view?usp=sharing"><span class="screen-reader-text">Download apk</span></a></li>
<li id="menu-item-24" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24"><a href="https://www.facebook.com/wordpress"><span class="screen-reader-text">Facebook</span></a></li>
<li id="menu-item-25" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-25"><a href="https://twitter.com/wordpress"><span class="screen-reader-text">Twitter</span></a></li>
<li id="menu-item-26" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-26"><a href="https://www.instagram.com/explore/tags/wordcamp/"><span class="screen-reader-text">Instagram</span></a></li>
<li id="menu-item-27" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-27"><a href="mailto:wordpress@example.com"><span class="screen-reader-text">Email</span></a></li>
</ul></div>					</div><!-- #header-social -->
							</div><!-- .container -->
		</div><!-- #tophead -->
		<header id="masthead" class="site-header" role="banner"><div class="container">				<div class="site-branding">

			<a href="<?php echo base_url(); ?>" class="custom-logo-link" rel="home" itemprop="url"><img width="636" height="208" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay2_1-1.png" class="custom-logo" alt="Mobile Payment SHOP" itemprop="logo" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay2_1-1.png 636w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay2_1-1-600x196.png 600w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay2_1-1-300x98.png 300w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay2_1-1-360x118.png 360w" sizes="(max-width: 636px) 100vw, 636px" /></a>
						
							<div id="site-identity">
																		<p class="site-title"><a href="http://localhost/Mopay_Dashboard/" rel="home">Mobile Payment SHOP</a></p>
											
											<p class="site-description">Easy Payment Easy Life</p>
									</div><!-- #site-identity -->
					</div><!-- .site-branding -->

		<div class="right-head">
					<div id="quick-contact">
			<ul class="quick-contact-list">
									<li class="quick-call">
													<strong>Phone</strong>
												<a href="tel:087736387081">087736387081</a>
					</li>
				
									<li class="quick-email">
													<strong>Email</strong>
												<a href="mailto:mopaySHOP@gmail.com">mopaySHOP@gmail.com</a>
					</li>
				
									<li class="quick-address">
													<strong>Address</strong>
																			Indonesia											</li>
							</ul><!-- .quick-contact-list -->
		</div><!--  .quick-contact -->
		
							<div class="cart-section">
					<div class="shopping-cart-views">
						<ul>
												<li class="cart-contents"><a href="http://localhost/Mopay_Dashboard/cart/">
							<i class="fa fa-cart-plus" aria-hidden="true"></i>
							<span class="cart-value"><span class="cart-items">0</span>&nbsp;<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>0.00</span></span>
						</a></li>
						</ul>
					</div><!-- .shopping-cart-views -->
				 </div><!-- .cart-section -->
					</div><!-- .right-head -->
			</div><!-- .container --></header><!-- #masthead --><div class="main-container">		<div id="main-nav" class="clear-fix">
			<div class="container">
						<div id="category-list">
			<a href="#"><i class="fa fa-align-left" aria-hidden="true"></i>All Categories</a>
			<ul>
				<li class="cat-item cat-item-19"><a href="http://localhost/Mopay_Dashboard/product-category/accessories/" >Accessories</a>
				</li>
				<li class="cat-item cat-item-20"><a href="http://localhost/Mopay_Dashboard/product-category/womens-collection/" >Women&#039;s Collection</a></li>
				<li class="cat-item cat-item-20"><a href="<?php echo base_url() ?>index.php/comodity/shop" >All Categories</a></li>
			</ul>
		</div><!-- #category-list -->
		
				<nav id="site-navigation" class="main-navigation" role="navigation">
					<div class="wrap-menu-content">
						<div class="menu-top-menu-container"><ul id="primary-menu" class="menu"><li class=" current-menu-item"><a href="http://localhost/Mopay_Dashboard/"><i class="fa fa-home" aria-hidden="true"></i>Home</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="http://localhost/Mopay_Dashboard/about/">About</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="http://localhost/Mopay_Dashboard/blog/">Blog</a></li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22 "></i><a href="https://drive.google.com/file/d/1EGAOLDNHpJ8J7pTfwxiETPf59jO3f-mO/view?usp=sharing">Download APK</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-28"><a href="http://localhost/Mopay/index.php/auth">Login</a></li>
</ul></div>					</div><!-- .wrap-menu-content -->
				</nav><!-- #site-navigation -->


													<div class="header-search-box">
						<a href="#" class="search-icon"><i class="fa fa-search"></i></a>
						<div class="search-box-wrap">
							<form role="search" method="get" class="search-form" action="http://localhost/Mopay_Dashboard/">
			<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" class="search-field" placeholder="Search&hellip;" value="" name="s" title="Search for:" />
			</label>
			<input type="submit" class="search-submit" value="&#xf002;" /></form>						</div>
					</div><!-- .header-search-box -->
				
			</div> <!-- .container -->
		</div><!-- #main-nav -->
		
<div id="main-featured-section" class="featured-section-widget-right featured-section-widget-disabled">
	<div class="container">
		<div class="inner-wrapper">
						<div class="featured-section-carousel">
				<div class="main-product-carousel-wrapper">
					<div class="inner-wrapper">
													<div class="main-product-carousel" data-slick='{"slidesToShow":3,"slidesToScroll":1,"dots":false,"prevArrow":"<span data-role=\"none\" class=\"slick-prev\" tabindex=\"0\"><i class=\"fa fa-angle-left\" aria-hidden=\"true\"><\/i><\/span>","nextArrow":"<span data-role=\"none\" class=\"slick-next\" tabindex=\"0\"><i class=\"fa fa-angle-right\" aria-hidden=\"true\"><\/i><\/span>","responsive":[{"breakpoint":479,"settings":{"slidesToShow":1}}],"autoplay":true,"autoplaySpeed":3000}'>

								
									<div class="main-product-carousel-item">
										<div class="main-product-carousel-item-inner">
																							<span class="featured-product-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>900,000.00</span></span>
																						<div class="product-thumb">
												<a href="http://localhost/Mopay_Dashboard/product/samsung-smart-watch/" class="product-thumb-wrapper">
																											<img src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-4.jpg" alt="" />
																									</a>
												<div class="view-details-wrapper">
													<a href="http://localhost/Mopay_Dashboard/product/samsung-smart-watch/" class="custom-button">View Details</a>
												</div><!-- .view-details-wrapper  -->
											</div><!-- .product-thumb -->
											<h3 class="main-product-carousel-title">
												<a href="http://localhost/Mopay_Dashboard/product/samsung-smart-watch/">Samsung Smart Watch</a>
											</h3>
										</div><!-- .main-product-carousel-item-inner -->
									</div><!-- .main-product-carousel-item -->

								
									<div class="main-product-carousel-item">
										<div class="main-product-carousel-item-inner">
																							<span class="featured-product-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>8,900,000.00</span></span>
																						<div class="product-thumb">
												<a href="http://localhost/Mopay_Dashboard/product/iphone-7-pluse/" class="product-thumb-wrapper">
																											<img src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-2.jpg" alt="" />
																									</a>
												<div class="view-details-wrapper">
													<a href="http://localhost/Mopay_Dashboard/product/iphone-7-pluse/" class="custom-button">View Details</a>
												</div><!-- .view-details-wrapper  -->
											</div><!-- .product-thumb -->
											<h3 class="main-product-carousel-title">
												<a href="http://localhost/Mopay_Dashboard/product/iphone-7-pluse/">iPhone 7 Pluse</a>
											</h3>
										</div><!-- .main-product-carousel-item-inner -->
									</div><!-- .main-product-carousel-item -->

								
									<div class="main-product-carousel-item">
										<div class="main-product-carousel-item-inner">
																							<span class="featured-product-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>15,000.00</span></span>
																						<div class="product-thumb">
												<a href="http://localhost/Mopay_Dashboard/product/pashmina-shawl/" class="product-thumb-wrapper">
																											<img src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960.jpg" alt="" />
																									</a>
												<div class="view-details-wrapper">
													<a href="http://localhost/Mopay_Dashboard/product/pashmina-shawl/" class="custom-button">View Details</a>
												</div><!-- .view-details-wrapper  -->
											</div><!-- .product-thumb -->
											<h3 class="main-product-carousel-title">
												<a href="http://localhost/Mopay_Dashboard/product/pashmina-shawl/">Pashmina Shawl</a>
											</h3>
										</div><!-- .main-product-carousel-item-inner -->
									</div><!-- .main-product-carousel-item -->

								
									<div class="main-product-carousel-item">
										<div class="main-product-carousel-item-inner">
																							<span class="featured-product-price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>100,000.00</span></span>
																						<div class="product-thumb">
												<a href="http://localhost/Mopay_Dashboard/product/beats-headphone/" class="product-thumb-wrapper">
																											<img src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-featured-5.jpg" alt="" />
																									</a>
												<div class="view-details-wrapper">
													<a href="http://localhost/Mopay_Dashboard/product/beats-headphone/" class="custom-button">View Details</a>
												</div><!-- .view-details-wrapper  -->
											</div><!-- .product-thumb -->
											<h3 class="main-product-carousel-title">
												<a href="http://localhost/Mopay_Dashboard/product/beats-headphone/">Beats Headphone</a>
											</h3>
										</div><!-- .main-product-carousel-item-inner -->
									</div><!-- .main-product-carousel-item -->

								
							</div><!-- .main-product-carousel -->
											</div><!-- .inner-wrapper -->
				</div><!-- .main-product-carousel-wrapper -->
			</div><!-- .featured-section-carousel -->
		</div><!-- .inner-wrapper -->
	</div><!-- .container -->
</div><!-- #main-featured-section -->

	<div id="content" class="site-content"><div class="container"><div class="inner-wrapper">	<div id="primary"><main role="main" class="site-main" id="main"><header class="woocommerce-products-header">
	
	</header>
<div class="woocommerce-notices-wrapper"></div><p class="woocommerce-result-count">
	Showing all 6 results</p>
<form class="woocommerce-ordering" method="get">
	<select name="orderby" class="orderby">
					<option value="menu_order"  selected='selected'>Default sorting</option>
					<option value="popularity" >Sort by popularity</option>
					<option value="rating" >Sort by average rating</option>
					<option value="date" >Sort by latest</option>
					<option value="price" >Sort by price: low to high</option>
					<option value="price-desc" >Sort by price: high to low</option>
			</select>
	<input type="hidden" name="paged" value="1" />
	</form>
<ul class="products columns-3">
<li class="post-79 product type-product status-publish has-post-thumbnail product_cat-accessories first instock virtual purchasable product-type-simple">
	<a href="http://localhost/Mopay_Dashboard/product/beats-headphone/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link"><img width="400" height="500" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-featured-5.jpg" class="attachment-best-commerce-product size-best-commerce-product" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-featured-5.jpg 400w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-featured-5-240x300.jpg 240w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-featured-5-216x270.jpg 216w" sizes="(max-width: 400px) 100vw, 400px" /><h2 class="woocommerce-loop-product__title">Beats Headphone</h2>
	<span class="price"><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>100,000.00</span></span>
</a><a href="/Mopay_Dashboard/?add-to-cart=79" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="79" data-product_sku="" aria-label="Add &ldquo;Beats Headphone&rdquo; to your cart" rel="nofollow">Add to cart</a></li>
<li class="post-106 product type-product status-publish has-post-thumbnail product_cat-accessories instock sale shipping-taxable purchasable product-type-simple">
	<a href="http://localhost/Mopay_Dashboard/product/iphone-7-pluse/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
	<span class="onsale">Sale!</span>
<img width="400" height="500" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-2.jpg" class="attachment-best-commerce-product size-best-commerce-product" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-2.jpg 400w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-2-240x300.jpg 240w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-2-216x270.jpg 216w" sizes="(max-width: 400px) 100vw, 400px" /><h2 class="woocommerce-loop-product__title">iPhone 7 Pluse</h2>
	<span class="price"><del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>9,000,000.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>8,900,000.00</span></ins></span>
</a><a href="/Mopay_Dashboard/?add-to-cart=106" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="106" data-product_sku="" aria-label="Add &ldquo;iPhone 7 Pluse&rdquo; to your cart" rel="nofollow">Add to cart</a></li>
<li class="post-95 product type-product status-publish has-post-thumbnail product_cat-accessories last instock sale shipping-taxable purchasable product-type-simple">
	<a href="http://localhost/Mopay_Dashboard/product/pashmina-shawl/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
	<span class="onsale">Sale!</span>
<img width="400" height="500" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960-400x500.jpg" class="attachment-best-commerce-product size-best-commerce-product" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960-400x500.jpg 400w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960-240x300.jpg 240w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960.jpg 768w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960-216x270.jpg 216w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960-600x750.jpg 600w" sizes="(max-width: 400px) 100vw, 400px" /><h2 class="woocommerce-loop-product__title">Pashmina Shawl</h2>
	<span class="price"><del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>20,000.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>15,000.00</span></ins></span>
</a><a href="/Mopay_Dashboard/?add-to-cart=95" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="95" data-product_sku="" aria-label="Add &ldquo;Pashmina Shawl&rdquo; to your cart" rel="nofollow">Add to cart</a></li>
<li class="post-109 product type-product status-publish has-post-thumbnail product_cat-accessories first instock sale purchasable product-type-simple">
	<a href="http://localhost/Mopay_Dashboard/product/samsung-smart-watch/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
	<span class="onsale">Sale!</span>
<img width="400" height="500" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-4.jpg" class="attachment-best-commerce-product size-best-commerce-product" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-4.jpg 400w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-4-240x300.jpg 240w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-4-216x270.jpg 216w" sizes="(max-width: 400px) 100vw, 400px" /><h2 class="woocommerce-loop-product__title">Samsung Smart Watch</h2>
	<span class="price"><del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>989,000.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>900,000.00</span></ins></span>
</a><a href="/Mopay_Dashboard/?add-to-cart=109" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="109" data-product_sku="" aria-label="Add &ldquo;Samsung Smart Watch&rdquo; to your cart" rel="nofollow">Add to cart</a></li>
<li class="post-97 product type-product status-publish has-post-thumbnail product_cat-womens-collection instock sale shipping-taxable purchasable product-type-simple">
	<a href="http://localhost/Mopay_Dashboard/product/summer-hat/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
	<span class="onsale">Sale!</span>
<img width="400" height="500" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-8-768x960-400x500.jpg" class="attachment-best-commerce-product size-best-commerce-product" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-8-768x960-400x500.jpg 400w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-8-768x960-240x300.jpg 240w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-8-768x960.jpg 768w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-8-768x960-216x270.jpg 216w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-8-768x960-600x750.jpg 600w" sizes="(max-width: 400px) 100vw, 400px" /><h2 class="woocommerce-loop-product__title">Summer Hat</h2>
	<span class="price"><del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>35,000.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>30,000.00</span></ins></span>
</a><a href="/Mopay_Dashboard/?add-to-cart=97" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="97" data-product_sku="" aria-label="Add &ldquo;Summer Hat&rdquo; to your cart" rel="nofollow">Add to cart</a></li>
<li class="post-104 product type-product status-publish has-post-thumbnail product_cat-womens-collection last instock sale shipping-taxable purchasable product-type-simple">
	<a href="http://localhost/Mopay_Dashboard/product/winter-overcoat/" class="woocommerce-LoopProduct-link woocommerce-loop-product__link">
	<span class="onsale">Sale!</span>
<img width="400" height="500" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-16-768x960-400x500.jpg" class="attachment-best-commerce-product size-best-commerce-product" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-16-768x960-400x500.jpg 400w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-16-768x960-240x300.jpg 240w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-16-768x960.jpg 768w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-16-768x960-216x270.jpg 216w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-16-768x960-600x750.jpg 600w" sizes="(max-width: 400px) 100vw, 400px" /><h2 class="woocommerce-loop-product__title">Winter Overcoat</h2>
	<span class="price"><del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>250,000.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>249,000.00</span></ins></span>
</a><a href="/Mopay_Dashboard/?add-to-cart=104" data-quantity="1" class="button product_type_simple add_to_cart_button ajax_add_to_cart" data-product_id="104" data-product_sku="" aria-label="Add &ldquo;Winter Overcoat&rdquo; to your cart" rel="nofollow">Add to cart</a></li>
</ul>
</main><!-- #main --></div><!-- #primary -->
<div id="sidebar-primary" class="widget-area sidebar" role="complementary">
			<aside id="woocommerce_product_categories-3" class="widget woocommerce widget_product_categories"><h2 class="widget-title">Product categories</h2><ul class="product-categories"><li class="cat-item cat-item-18"><a href="http://localhost/Mopay_Dashboard/product-category/uncategorized/">Uncategorized</a> <span class="count">(0)</span></li>
<li class="cat-item cat-item-19"><a href="http://localhost/Mopay_Dashboard/product-category/accessories/">Accessories</a> <span class="count">(4)</span></li>
<li class="cat-item cat-item-22"><a href="http://localhost/Mopay_Dashboard/product-category/http-localhost-mopay-index-php-auth/">coba</a> <span class="count">(0)</span></li>
<li class="cat-item cat-item-20"><a href="http://localhost/Mopay_Dashboard/product-category/womens-collection/">Women's Collection</a> <span class="count">(2)</span></li>
</ul></aside><aside id="woocommerce_product_search-3" class="widget woocommerce widget_product_search"><form role="search" method="get" class="woocommerce-product-search" action="http://localhost/Mopay_Dashboard/">
	<label class="screen-reader-text" for="woocommerce-product-search-field-0">Search for:</label>
	<input type="search" id="woocommerce-product-search-field-0" class="search-field" placeholder="Search products&hellip;" value="" name="s" />
	<button type="submit" value="Search">Search</button>
	<input type="hidden" name="post_type" value="product" />
</form>
</aside><aside id="woocommerce_products-3" class="widget woocommerce widget_products"><ul class="product_list_widget"><li>
	
	<a href="http://localhost/Mopay_Dashboard/product/samsung-smart-watch/">
		<img width="300" height="300" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-4-300x300.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-4-300x300.jpg 300w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-4-150x150.jpg 150w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-4-100x100.jpg 100w" sizes="(max-width: 300px) 100vw, 300px" />		<span class="product-title">Samsung Smart Watch</span>
	</a>

				
	<del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>989,000.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>900,000.00</span></ins>
	</li>
<li>
	
	<a href="http://localhost/Mopay_Dashboard/product/iphone-7-pluse/">
		<img width="300" height="300" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-2-300x300.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-2-300x300.jpg 300w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-2-150x150.jpg 150w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-business-featured-2-100x100.jpg 100w" sizes="(max-width: 300px) 100vw, 300px" />		<span class="product-title">iPhone 7 Pluse</span>
	</a>

				
	<del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>9,000,000.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>8,900,000.00</span></ins>
	</li>
<li>
	
	<a href="http://localhost/Mopay_Dashboard/product/winter-overcoat/">
		<img width="300" height="300" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-16-768x960-300x300.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-16-768x960-300x300.jpg 300w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-16-768x960-150x150.jpg 150w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-16-768x960-100x100.jpg 100w" sizes="(max-width: 300px) 100vw, 300px" />		<span class="product-title">Winter Overcoat</span>
	</a>

				
	<del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>250,000.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>249,000.00</span></ins>
	</li>
<li>
	
	<a href="http://localhost/Mopay_Dashboard/product/summer-hat/">
		<img width="300" height="300" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-8-768x960-300x300.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-8-768x960-300x300.jpg 300w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-8-768x960-150x150.jpg 150w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-8-768x960-100x100.jpg 100w" sizes="(max-width: 300px) 100vw, 300px" />		<span class="product-title">Summer Hat</span>
	</a>

				
	<del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>35,000.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>30,000.00</span></ins>
	</li>
<li>
	
	<a href="http://localhost/Mopay_Dashboard/product/pashmina-shawl/">
		<img width="300" height="300" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960-300x300.jpg" class="attachment-woocommerce_thumbnail size-woocommerce_thumbnail" alt="" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960-300x300.jpg 300w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960-150x150.jpg 150w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/best-commerce-pro-product-30-768x960-100x100.jpg 100w" sizes="(max-width: 300px) 100vw, 300px" />		<span class="product-title">Pashmina Shawl</span>
	</a>

				
	<del><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>20,000.00</span></del> <ins><span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>15,000.00</span></ins>
	</li>
</ul></aside>	</div><!-- #sidebar-primary -->
</div><!-- .inner-wrapper --></div><!-- .container --></div><!-- #content -->

<footer id="colophon" class="site-footer" role="contentinfo">
<div class="container">	
	<div class="copyright">
				<i class="fa fa-copyright"></i>Copyright 2018 | Mobile Payment - ABDULLAH AFLAHA ASLAM<a target="_blank" href="https://ignasiusleo.com"> - IGNASIUS AGUS LEONARDO</a>

			<span class="sep"> | </span>
			Best Commerce by <a href="https://axlethemes.com">Imbisil.CORP</a>		
	</div>
	<div class="site-info">
			<center>
			 <a href="">DOWNLOAD APK</a>	
			<br>
			<img width="100" height="100"  src="https://chart.googleapis.com/chart?cht=qr&chl=https://drive.google.com/file/d/1EGAOLDNHpJ8J7pTfwxiETPf59jO3f-mO/view?usp=sharing/&chs=180x180&choe=UTF-8&chld=L|2" alt="image" class="pull-left attachment-best-commerce-product size-best-commerce-product"/>	
			&nbsp;&nbsp;&nbsp;<a href="https://drive.google.com/file/d/1EGAOLDNHpJ8J7pTfwxiETPf59jO3f-mO/view?usp=sharing" itemprop="url"><img width="100" height="100" src="https://cdngarenanow-a.akamaihd.net/shopee/shopee-pcmall-live-id/assets/df3ffda2f31c9ca2b52423dfd5deb146.png" alt="App Store"> </a><br>
			&nbsp;&nbsp;&nbsp;<a href="https://drive.google.com/file/d/1EGAOLDNHpJ8J7pTfwxiETPf59jO3f-mO/view?usp=sharing" itemprop="url"><img width="100" height="100" src="https://cdngarenanow-a.akamaihd.net/shopee/shopee-pcmall-live-id/assets/2679f513b5f9e235adf2c6c288617e7b.png" alt="Play Store"></a>
			</center>
	</div>
</div><!-- .container -->

</footer><!-- #colophon -->
</div> <!-- .main-container --></div><!-- #page --><a href="#page" class="scrollup" id="btn-scrollup"><i class="fa fa-angle-up"></i></a>
<script type="application/ld+json">{"@context":"https:\/\/schema.org\/","@graph":[{"@context":"https:\/\/schema.org\/","@type":"WebSite","name":"Mobile Payment SHOP","url":"http:\/\/localhost\/Mopay_Dashboard","potentialAction":{"@type":"SearchAction","target":"http:\/\/localhost\/Mopay_Dashboard\/?s={search_term_string}&post_type=product","query-input":"required name=search_term_string"}},{"@context":"https:\/\/schema.org\/","@graph":[{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/beats-headphone\/","name":"Beats Headphone","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/beats-headphone\/"},{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/iphone-7-pluse\/","name":"iPhone 7 Pluse","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/iphone-7-pluse\/"},{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/pashmina-shawl\/","name":"Pashmina Shawl","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/pashmina-shawl\/"},{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/samsung-smart-watch\/","name":"Samsung Smart Watch","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/samsung-smart-watch\/"},{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/summer-hat\/","name":"Summer Hat","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/summer-hat\/"},{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/winter-overcoat\/","name":"Winter Overcoat","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/winter-overcoat\/"}]}]}</script>	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/Mopay_Dashboard\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/Mopay_Dashboard\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/localhost\/Mopay_Dashboard\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.5.2'></script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/Mopay_Dashboard\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/Mopay_Dashboard\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.5.2'></script>
<script type='text/javascript'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/Mopay_Dashboard\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/Mopay_Dashboard\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_906c7a760ab633bb338e036c60a5d806","fragment_name":"wc_fragments_906c7a760ab633bb338e036c60a5d806"};
/* ]]> */
</script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.5.2'></script>
<script type='text/javascript'>
		jQuery( 'body' ).bind( 'wc_fragments_refreshed', function() {
			jQuery( 'body' ).trigger( 'jetpack-lazy-images-load' );
		} );
	
</script>
<script type='text/javascript'>
/* <![CDATA[ */
var mailchimp_public_data = {"site_url":"http:\/\/localhost\/Mopay_Dashboard","ajax_url":"http:\/\/localhost\/Mopay_Dashboard\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-content/plugins/mailchimp-for-woocommerce/public/js/mailchimp-woocommerce-public.min.js?ver=2.1.11'></script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/js/skip-link-focus-fix.min.js?ver=20130115'></script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/vendors/sidr/js/jquery.sidr.min.js?ver=2.2.1'></script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/vendors/slick/slick.min.js?ver=1.5.9'></script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/js/custom.min.js?ver=1.0.0'></script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-includes/js/wp-embed.min.js?ver=4.9.9'></script>
</body>
</html>
