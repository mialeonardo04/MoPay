
<!DOCTYPE html><html lang="en-US"><head>
			<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="profile" href="http://gmpg.org/xfn/11">
		
<title>Mobile Payment SHOP &#8211; Easy Payment Easy Life</title>
<script src='https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js'></script>
<script src='https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js'></script>
<link rel='dns-prefetch' href='//fonts.googleapis.com' />
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Mobile Payment SHOP &raquo; Feed" href="http://localhost/Mopay_Dashboard/feed/" />
<link rel="alternate" type="application/rss+xml" title="Mobile Payment SHOP &raquo; Comments Feed" href="http://localhost/Mopay_Dashboard/comments/feed/" />
<link rel="alternate" type="application/rss+xml" title="Mobile Payment SHOP &raquo; Products Feed" href="http://localhost/Mopay_Dashboard/shop/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/localhost\/Mopay_Dashboard\/wp-includes\/js\/wp-emoji-release.min.js?ver=4.9.9"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
table {
	border-color: red !important;
	 border-style: none !important;
}
</style>
<link rel='stylesheet' id='woocommerce-layout-css'  href='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/css/woocommerce-layout.css?ver=3.5.2' type='text/css' media='all' />
<style id='woocommerce-layout-inline-css' type='text/css'>

	.infinite-scroll .woocommerce-pagination {
		display: none;
	}
</style>
<link rel='stylesheet' id='woocommerce-smallscreen-css'  href='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/css/woocommerce-smallscreen.css?ver=3.5.2' type='text/css' media='only screen and (max-width: 768px)' />
<link rel='stylesheet' id='woocommerce-general-css'  href='http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/css/woocommerce.css?ver=3.5.2' type='text/css' media='all' />
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='font-awesome-css'  href='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/vendors/font-awesome/css/font-awesome.min.css?ver=4.7.0' type='text/css' media='all' />
<link rel='stylesheet' id='best-commerce-google-fonts-css'  href='https://fonts.googleapis.com/css?family=Roboto%3A300%2C400%2C500%2C700%7CMontserrat%3A300%2C400%2C500%2C600%2C700&#038;subset=latin%2Clatin-ext' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-sidr-css'  href='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/vendors/sidr/css/jquery.sidr.dark.min.css?ver=2.2.1' type='text/css' media='all' />
<link rel='stylesheet' id='jquery-slick-css'  href='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/vendors/slick/slick.min.css?ver=1.5.9' type='text/css' media='all' />
<link rel='stylesheet' id='best-commerce-style-css'  href='http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/style.css?ver=1.0.6' type='text/css' media='all' />
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-includes/js/jquery/jquery.js?ver=1.12.4'></script>
<script type='text/javascript' src='http://localhost/Mopay_Dashboard/wp-includes/js/jquery/jquery-migrate.min.js?ver=1.4.1'></script>
<link rel='https://api.w.org/' href='http://localhost/Mopay_Dashboard/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost/Mopay_Dashboard/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://localhost/Mopay_Dashboard/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 4.9.9" />
<meta name="generator" content="WooCommerce 3.5.2" />
<meta name="referrer" content="always"/>	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<link rel="icon" href="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay3-1-32x32.png" sizes="32x32" />
<link rel="icon" href="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay3-1-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon-precomposed" href="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay3-1-180x180.png" />
<meta name="msapplication-TileImage" content="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay3-1-270x270.png" />
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/js-cookie@2/src/js.cookie.min.js"></script>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">


<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Mobile Payment </title>
   <!--  <link rel="icon" type="image/png" sizes="16x16" href="<?php echo base_url(); ?>assets\login\img\logo.png"> -->
    <!-- Bootstrap -->
    <link href="<?php echo base_url(); ?>assets/home/vendors/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link href="<?php echo base_url(); ?>assets/home/vendors/font-awesome/css/font-awesome.min.css" rel="stylesheet">
    <!-- NProgress -->
    <link href="<?php echo base_url(); ?>assets/home/vendors/nprogress/nprogress.css" rel="stylesheet">
    <!-- iCheck -->
    <link href="<?php echo base_url(); ?>assets/home/vendors/iCheck/skins/flat/green.css" rel="stylesheet">
  









</head>



<body style="background: none;" class="home archive post-type-archive post-type-archive-product wp-custom-logo woocommerce woocommerce-page woocommerce-js site-layout-boxed global-layout-right-sidebar">

	<div id="page" class="hfeed site"><a class="skip-link screen-reader-text" href="#content">Skip to content</a>		<div class="mobile-nav-wrap">
			<a id="mobile-trigger" href="#mob-menu"><i class="fa fa-list-ul" aria-hidden="true"></i></a>
										<a id="mobile-trigger2" href="#category-list"><i class="fa fa-folder-o" aria-hidden="true"></i></a>
						<div id="mob-menu">
				<ul id="menu-top-menu" class="menu"><li class=" current-menu-item"><a href="http://localhost/Mopay_Dashboard/"><i class="fa fa-home" aria-hidden="true"></i>Home</a></li><li id="menu-item-20" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="http://localhost/Mopay_Dashboard/about/">About</a></li>
<li id="menu-item-21" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="http://localhost/Mopay_Dashboard/blog/">Blog</a></li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22"><a href="http://localhost/Mopay_Dashboard/contact/">Contact</a></li>
<li id="menu-item-28" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-28"><a href="http://localhost/Mopay/index.php/auth">Login</a></li>
</ul>			</div><!-- #mob-menu -->

		</div><!-- .mobile-nav-wrap -->
		
			<div id="tophead">
			<div class="container">

				
						<div class="my-login">
			<ul>
									<li>
						<a href="http://localhost/Mopay_Dashboard/my-account/"><i class="fa fa-user" aria-hidden="true"></i>Login/Register</a>
					</li>
							</ul>
		</div><!-- .my-login -->
		
									<div id="header-social">
						<div class="widget best_commerce_widget_social"><ul id="menu-social-links-menu" class="menu"><li id="menu-item-23" class="fa fa-download menu-item menu-item-type-custom menu-item-object-custom menu-item-23"><a title="Download APK" target="_blank" href="https://drive.google.com/file/d/1EGAOLDNHpJ8J7pTfwxiETPf59jO3f-mO/view?usp=sharing"><span class="screen-reader-text">Download apk</span></a></li>
<li id="menu-item-24" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-24"><a href="https://www.facebook.com/wordpress"><span class="screen-reader-text">Facebook</span></a></li>
<li id="menu-item-25" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-25"><a href="https://twitter.com/wordpress"><span class="screen-reader-text">Twitter</span></a></li>
<li id="menu-item-26" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-26"><a href="https://www.instagram.com/explore/tags/wordcamp/"><span class="screen-reader-text">Instagram</span></a></li>
<li id="menu-item-27" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-27"><a href="mailto:wordpress@example.com"><span class="screen-reader-text">Email</span></a></li>
</ul></div>					</div><!-- #header-social -->
							</div><!-- .container -->
		</div><!-- #tophead -->
		<header id="masthead" class="site-header" role="banner"><div class="container">				<div class="site-branding">

			<a href="http://localhost/Mopay/" class="custom-logo-link" rel="home" itemprop="url"><img width="636" height="208" src="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay2_1-1.png" class="custom-logo" alt="Mobile Payment SHOP" itemprop="logo" srcset="http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay2_1-1.png 636w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay2_1-1-600x196.png 600w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay2_1-1-300x98.png 300w, http://localhost/Mopay_Dashboard/wp-content/uploads/2018/12/cropped-mopay2_1-1-360x118.png 360w" sizes="(max-width: 636px) 100vw, 636px"></a>
						
							<div id="site-identity">
																		<p class="site-title"><a href="http://localhost/Mopay_Dashboard/" rel="home">Mobile Payment SHOP</a></p>
											
											<p class="site-description">Easy Payment Easy Life</p>
									</div><!-- #site-identity -->
					</div><!-- .site-branding -->

		<div class="right-head">
					<div id="quick-contact">
			<ul class="quick-contact-list">
									<li class="quick-call">
													<strong>Phone</strong>
												<a href="tel:087736387081">087736387081</a>
					</li>
				
									<li class="quick-email">
													<strong>Email</strong>
												<a href="mailto:mopaySHOP@gmail.com">mopaySHOP@gmail.com</a>
					</li>
				
									<li class="quick-address">
													<strong>Address</strong>
																			Indonesia											</li>
							</ul><!-- .quick-contact-list -->
		</div><!--  .quick-contact -->
		
							<div class="cart-section">
					<div class="shopping-cart-views">
						<ul>
												<li class="cart-contents"><a href="http://localhost/Mopay_Dashboard/cart/">
							<i class="fa fa-cart-plus" aria-hidden="true"></i>
							<span class="cart-value"><span class="cart-items">0</span>&nbsp;<span class="woocommerce-Price-amount amount"><span class="woocommerce-Price-currencySymbol">Rp</span>0.00</span></span>
						</a></li>
						</ul>
					</div><!-- .shopping-cart-views -->
				 </div><!-- .cart-section -->
					</div><!-- .right-head -->
			</div><!-- .container --></header><!-- #masthead --><div class="main-container">		<div id="main-nav" class="clear-fix">
			<div class="container">
						<div id="category-list">
			<a href="#"><i class="fa fa-align-left" aria-hidden="true"></i>All Categories</a>
			<ul>
				<li class="cat-item cat-item-19"><a href="http://localhost/Mopay_Dashboard/product-category/accessories/">Accessories</a>
				</li>
				<li class="cat-item cat-item-20"><a href="http://localhost/Mopay_Dashboard/product-category/womens-collection/">Women's Collection</a></li>
				<li class="cat-item cat-item-20"><a href="http://localhost/Mopay/index.php/comodity/shop">All Categories</a></li>
			</ul>
		</div><!-- #category-list -->
		
				<nav id="site-navigation" class="main-navigation" role="navigation">
					<div class="wrap-menu-content">
						<div class="menu-top-menu-container"><ul id="primary-menu" class="menu"><li class=" current-menu-item"><a href="http://localhost/Mopay_Dashboard/"><i class="fa fa-home" aria-hidden="true"></i>Home</a></li><li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-20"><a href="http://localhost/Mopay_Dashboard/about/">About</a></li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21"><a href="http://localhost/Mopay_Dashboard/blog/">Blog</a></li>
<li id="menu-item-22" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-22 "></i><a href="https://drive.google.com/file/d/1EGAOLDNHpJ8J7pTfwxiETPf59jO3f-mO/view?usp=sharing">Download APK</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-28"><a href="http://localhost/Mopay/index.php/auth">Login</a></li>
</ul></div>					</div><!-- .wrap-menu-content -->
				</nav><!-- #site-navigation -->


													<div class="header-search-box">
						<a href="#" class="search-icon"><i class="fa fa-search"></i></a>
						<div class="search-box-wrap">
							<form role="search" method="get" class="search-form" action="http://localhost/Mopay_Dashboard/">
			<label>
			<span class="screen-reader-text">Search for:</span>
			<input type="search" class="search-field" placeholder="Search…" value="" name="s" title="Search for:">
			</label>
			<input type="submit" class="search-submit" value=""></form>						</div>
					</div><!-- .header-search-box -->
				
			</div> <!-- .container -->
		</div><!-- #main-nav -->
		
<!-- #main-featured-section -->











<div class="container body">
      <div class="main_container">
       

        <!-- top navigation -->
      

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="main">
          <br>
    <form class="form-horizontal form-label-left" >

                      <p>Select amount and confirm to buy, <code>*</code> 
                      </p>
                      <span class="section ">Mopay SHOP </span>

                      <table class="table table-hover">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Product</th>
                          <th>Unit Price</th>
                          <th>Quantity</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row"><i class="fa fa-check-square"></i></th>
                          <td>
                            <input id="ID_Com" class="form-control col-md-7 col-xs-12" data-validate-length-range="6" data-validate-words="2" name="name"  required="required" type="hidden">
                            <input type="text" id="Name" name="text" required="required" class="form-control col-md-7 col-xs-12" readonly="readolny">
                          </td>
                          <td>
                            <input type="Number" id="Price" name="Price" data-validate-linked="Price" required="required" class="form-control col-md-7 col-xs-12" readonly="readolny">
                          </td>
                          <td>
                            <input id="qty" type="number"  name="qty" onchange="tambah(this.value)" class="form-control col-md-7 col-xs-12" required="required">
                          </td>
                        </tr>
                      </tbody>
                    </table>
                      
                                        
                      
                        
                      <div class="ln_solid "></div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Total Price </label>
                        <div class="col-md-9 col-sm-9 col-xs-12">
                          <input id="total" type="number"  name="qty" class="" required="required" disabled="disabled" >
                        </div>
                      </div>
                      <div class="form-group r">
                        <div class="col-md-6 col-md-offset-3">  
                          <a style=" color:white; " href="<?php echo base_url(); ?>index.php/comodity/shop" class="btn btn-primary">Cancel</a>

                          <a type="button" name="submit" value="Submit" id="submit" class="btn btn-primary" data-toggle="modal" data-target="#myModal"/>Submit</a>
                          <!-- <button id="submit" type="submit" class="btn btn-success">Submit</button> -->
                           </form>
                        </div>
                      </div>
                      
					<!-- <div class="col-md-55">
                        <div class="thumbnail" id="coba">
                            <img width="400" height="500"  src="http://localhost/Mopay/assets/home/production/images/media.jpg" alt="image" class="attachment-best-commerce-product size-best-commerce-product"/>
                              <h2 class="woocommerce-loop-product__title">Beats Headphone</h2>
                              	<h3><i class="fa fa-money"></i></h3>
                                <a href="#">description</a>                        
                           <h4 class="woocommerce-loop-product__title">RP 100.000</h4>
                          
                        </div>
                    </div> -->
                    
 		 </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
       <!--  <footer>
          <div class="pull-right">
            Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
          </div>
          <div class="clearfix"></div>
        </footer> -->
        <!-- /footer content -->
      </div>
    </div>










<!-- #content -->
	
<footer id="colophon" class="site-footer" role="contentinfo">
<div class="container">	
	<div class="copyright">
				<i class="fa fa-copyright"></i>Copyright 2018 | Mobile Payment - ABDULLAH AFLAHA ASLAM<a target="_blank" href="https://ignasiusleo.com"> - IGNASIUS AGUS LEONARDO</a>

			<span class="sep"> | </span>
			Best Commerce by <a href="https://axlethemes.com">Imbisil.CORP</a>		
	</div>
	<div class="site-info">
			<center>
			 <a href="">DOWNLOAD APK</a>	
			<br>
			<img width="100" height="100"  src="https://chart.googleapis.com/chart?cht=qr&chl=https://drive.google.com/file/d/1EGAOLDNHpJ8J7pTfwxiETPf59jO3f-mO/view?usp=sharing/&chs=180x180&choe=UTF-8&chld=L|2" alt="image" class="pull-left attachment-best-commerce-product size-best-commerce-product"/>	
			&nbsp;&nbsp;&nbsp;<a href="https://drive.google.com/file/d/1EGAOLDNHpJ8J7pTfwxiETPf59jO3f-mO/view?usp=sharing" itemprop="url"><img width="100" height="100" src="https://cdngarenanow-a.akamaihd.net/shopee/shopee-pcmall-live-id/assets/df3ffda2f31c9ca2b52423dfd5deb146.png" alt="App Store"> </a><br>
			&nbsp;&nbsp;&nbsp;<a href="https://drive.google.com/file/d/1EGAOLDNHpJ8J7pTfwxiETPf59jO3f-mO/view?usp=sharing" itemprop="url"><img width="100" height="100" src="https://cdngarenanow-a.akamaihd.net/shopee/shopee-pcmall-live-id/assets/2679f513b5f9e235adf2c6c288617e7b.png" alt="Play Store"></a>
			</center>
	</div>
</div><!-- .container -->

</footer><!-- #colophon -->
	
</div> <!-- .main-container --></div><!-- #page --><a href="#page" class="scrollup" id="btn-scrollup" style="display: none;"><i class="fa fa-angle-up"></i></a>
<script type="application/ld+json">{"@context":"https:\/\/schema.org\/","@graph":[{"@context":"https:\/\/schema.org\/","@type":"WebSite","name":"Mobile Payment SHOP","url":"http:\/\/localhost\/Mopay_Dashboard","potentialAction":{"@type":"SearchAction","target":"http:\/\/localhost\/Mopay_Dashboard\/?s={search_term_string}&post_type=product","query-input":"required name=search_term_string"}},{"@context":"https:\/\/schema.org\/","@graph":[{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/beats-headphone\/","name":"Beats Headphone","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/beats-headphone\/"},{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/iphone-7-pluse\/","name":"iPhone 7 Pluse","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/iphone-7-pluse\/"},{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/pashmina-shawl\/","name":"Pashmina Shawl","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/pashmina-shawl\/"},{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/samsung-smart-watch\/","name":"Samsung Smart Watch","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/samsung-smart-watch\/"},{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/summer-hat\/","name":"Summer Hat","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/summer-hat\/"},{"@type":"Product","@id":"http:\/\/localhost\/Mopay_Dashboard\/product\/winter-overcoat\/","name":"Winter Overcoat","url":"http:\/\/localhost\/Mopay_Dashboard\/product\/winter-overcoat\/"}]}]}</script>	<script type="text/javascript">
		var c = document.body.className;
		c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
		document.body.className = c;
	</script>
	<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70"></script>
<script type="text/javascript">
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/Mopay_Dashboard\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/Mopay_Dashboard\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"http:\/\/localhost\/Mopay_Dashboard\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=3.5.2"></script>
<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4"></script>
<script type="text/javascript">
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/Mopay_Dashboard\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/Mopay_Dashboard\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=3.5.2"></script>
<script type="text/javascript">
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/Mopay_Dashboard\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/Mopay_Dashboard\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_906c7a760ab633bb338e036c60a5d806","fragment_name":"wc_fragments_906c7a760ab633bb338e036c60a5d806"};
/* ]]> */
</script>
<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=3.5.2"></script>
<script type="text/javascript">
		jQuery( 'body' ).bind( 'wc_fragments_refreshed', function() {
			jQuery( 'body' ).trigger( 'jetpack-lazy-images-load' );
		} );
	
</script>
<script type="text/javascript">
/* <![CDATA[ */
var mailchimp_public_data = {"site_url":"http:\/\/localhost\/Mopay_Dashboard","ajax_url":"http:\/\/localhost\/Mopay_Dashboard\/wp-admin\/admin-ajax.php"};
/* ]]> */
</script>
<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-content/plugins/mailchimp-for-woocommerce/public/js/mailchimp-woocommerce-public.min.js?ver=2.1.11"></script>
<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/js/skip-link-focus-fix.min.js?ver=20130115"></script>
<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/vendors/sidr/js/jquery.sidr.min.js?ver=2.2.1"></script>
<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/vendors/slick/slick.min.js?ver=1.5.9"></script>
<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-content/themes/best-commerce/js/custom.min.js?ver=1.0.0"></script>
<script type="text/javascript" src="http://localhost/Mopay_Dashboard/wp-includes/js/wp-embed.min.js?ver=4.9.9"></script>



  <!-- jQuery -->
    <script src="http://localhost/Mopay/assets/home/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="http://localhost/Mopay/assets/home/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="http://localhost/Mopay/assets/home/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="http://localhost/Mopay/assets/home/vendors/nprogress/nprogress.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="http://localhost/Mopay/assets/home/build/js/custom.min.js"></script>
<script type="text/javascript">
///coba


function ExecuteQuery(query, callback){
  $.post("https://api.ignasiusleo.com/commodity", query,
   function(data){ callback(data);  },
   "json");
}

var keyword = <?php echo $id ?>;
var katakunci = {'ID_Com': keyword};
var b=[];
ExecuteQuery(katakunci,function(results){
  b = results;
  
  num  =parseInt(b[0]['Price'] );
  document.getElementById("Name").value = b[0]['Name'];
  document.getElementById("Price").value =(num/1000).toFixed(3);
  document.getElementById("nabar").innerHTML =  b[0]['Name'];
});

tambah = function(){
  var tambah = document.getElementById("qty").value;
  var total = parseInt (tambah)* num;
  document.getElementById("total").value =(total/1000).toFixed(3);
  document.getElementById("gambar").src = 'https://chart.googleapis.com/chart?cht=qr&chl='+<?php echo $id ?>+'/'+tambah+'/'+total+'/&chs=180x180&choe=UTF-8&chld=L|2';
  document.getElementById("tothar").innerHTML =  "Paid amount: Rp."+total+",-";
  }
/*function formatCurrency(num) {

        num = num.toString().replace(/\Rp|/g,'');
        if(isNaN(num))
            num = "0";
        sign = (num == (num = Math.abs(num)));
        num = Math.floor(num*100+0.50000000001);
        cents = num%100;
        num = Math.floor(num/100).toString();
        if(cents<10)
            cents = "0" + cents;
        for (var i = 0; i < Math.floor((num.length-(1+i))/3); i++)
            num = num.substring(0,num.length-(4*i+3))+'.'+
            num.substring(num.length-(4*i+3));
        asem =toString( ((sign)?'':'-') + 'Rp ' + num + ',' + cents);
        return asem;
    }*/
</script>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                    <h4 class="modal-title" id="myModalLabel">QR Code</h4>
                                </div>
                                <div id="dvContainer">
                                  <div class="modal-body">
                                        <center><img id= "gambar" >
                                        <h4 id="nabar"></h4>
                                        <h4 id="tothar"></h4>
                                        </center>
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-primary">Right Click->save Barcode</button>
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>


<div id="sidr-main" class="sidr left" style="transition: left 0.5s ease-in-out 0s;"><div class="sidr-inner">
				<ul id="sidr-id-menu-top-menu" class="sidr-class-menu"><li class=" sidr-class-current-menu-item"><a href="http://localhost/Mopay_Dashboard/"><i class="sidr-class-fa sidr-class-fa-home" aria-hidden="true"></i>Home</a></li><li id="sidr-id-menu-item-20" class="sidr-class-menu-item sidr-class-menu-item-type-post_type sidr-class-menu-item-object-page sidr-class-menu-item-20"><a href="http://localhost/Mopay_Dashboard/about/">About</a></li>
<li id="sidr-id-menu-item-21" class="sidr-class-menu-item sidr-class-menu-item-type-post_type sidr-class-menu-item-object-page sidr-class-menu-item-21"><a href="http://localhost/Mopay_Dashboard/blog/">Blog</a></li>
<li id="sidr-id-menu-item-22" class="sidr-class-menu-item sidr-class-menu-item-type-post_type sidr-class-menu-item-object-page sidr-class-menu-item-22"><a href="http://localhost/Mopay_Dashboard/contact/">Contact</a></li>
<li id="sidr-id-menu-item-28" class="sidr-class-menu-item sidr-class-menu-item-type-custom sidr-class-menu-item-object-custom sidr-class-menu-item-28"><a href="http://localhost/Mopay/index.php/auth">Login</a></li>
</ul>			</div></div><div id="sidr-category" class="sidr right" style="transition: right 0.5s ease-in-out 0s;"><div class="sidr-inner">
			<a href="#"><i class="sidr-class-fa sidr-class-fa-align-left" aria-hidden="true"></i>All Categories</a>
			<ul>
				<li class="sidr-class-cat-item sidr-class-cat-item-19"><a href="http://localhost/Mopay_Dashboard/product-category/accessories/">Accessories</a>
				</li>
				<li class="sidr-class-cat-item sidr-class-cat-item-20"><a href="http://localhost/Mopay_Dashboard/product-category/womens-collection/">Women's Collection</a></li>
				<li class="sidr-class-cat-item sidr-class-cat-item-20"><a href="http://localhost/Mopay/index.php/comodity/shop">All Categories</a></li>
			</ul>
		</div></div>


   <!-- jQuery -->
    <script src="<?php  echo base_url(); ?>assets/home/vendors/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php  echo base_url(); ?>assets/home/vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- FastClick -->
    <script src="<?php  echo base_url(); ?>assets/home/vendors/fastclick/lib/fastclick.js"></script>
    <!-- NProgress -->
    <script src="<?php  echo base_url(); ?>assets/home/vendors/nprogress/nprogress.js"></script>
    <!-- Chart.js -->
    <script src="<?php  echo  base_url(); ?>assets/home/vendors/Chart.js/dist/Chart.min.js"></script>
    <!-- gauge.js -->
    <script src="<?php  echo  base_url(); ?>assets/home/vendors/gauge.js/dist/gauge.min.js"></script>
    <!-- bootstrap-progressbar -->
    <script src="<?php  echo base_url(); ?>assets/home/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js"></script>
    <!-- iCheck -->
    <script src="<?php  echo  base_url(); ?>assets/home/vendors/iCheck/icheck.min.js"></script>
    <!-- Skycons -->
    <script src="<?php  echo base_url(); ?>assets/home/vendors/skycons/skycons.js"></script>
    <!-- Flot -->
    <script src="<?php  echo base_url(); ?>assets/home/vendors/Flot/jquery.flot.js"></script>
    <script src="<?php  echo  base_url(); ?>assets/home/vendors/Flot/jquery.flot.pie.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/Flot/jquery.flot.time.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/Flot/jquery.flot.stack.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/Flot/jquery.flot.resize.js"></script>
    <!-- Flot plugins -->
    <script src="<?php  echo base_url(); ?>assets/home/vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/flot.curvedlines/curvedLines.js"></script>
    <!-- DateJS -->
    <script src="<?php echo  base_url(); ?>assets/home/vendors/DateJS/build/date.js"></script>
    <!-- JQVMap -->
    <script src="<?php  echo base_url(); ?>assets/home/vendors/jqvmap/dist/jquery.vmap.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php  echo base_url(); ?>assets/home/vendors/moment/min/moment.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

    <!-- Custom Theme Scripts -->
    <script src="<?php  echo base_url(); ?>assets/home/build/js/custom.min.js"></script>

    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php  echo base_url(); ?>assets/home/vendors/pdfmake/build/vfs_fonts.js"></script>
		</body>
</html>
